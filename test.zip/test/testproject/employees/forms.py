from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django import forms
from employees.models import Employee

class AuthForm(AuthenticationForm):
	class Meta:
		model = User
		fields = ['username','password']
		# widgets = {
        #     'password': forms.TextInput(attrs={'title':'dhfbjhd'}),
        # }
		# labels={'password':'Pwd'}

class NewSignUpForm(UserCreationForm):
	password2 = forms.CharField(label='Re-Password',widget=forms.PasswordInput())
	class Meta:
		model = User
		fields = ['username','first_name','last_name','email']
		labels={'email':'Email'}

class EmployeeForm(forms.ModelForm):
	class Meta:
		model = Employee
		fields = ['name','aadharNumber','gender','contactnum','address','salary']
		widgets = {
			'name':forms.TextInput(attrs={'class':'form-control','id':'nameid'}),
			'salary':forms.TextInput(attrs={'class':'form-control','id':'salaryid'}),
			'aadharNumber':forms.TextInput(attrs={'class':'form-control','id':'aadharid'}),
			'gender':forms.TextInput(attrs={'class':'form-control','id':'genderid'}),
			'contactnum':forms.TextInput(attrs={'class':'form-control','id':'numid'}),
			'address':forms.TextInput(attrs={'class':'form-control','id':'addid'}),
			}
		labels = {
            'name': ('Full Name'),
			'aadharNumber':('Aadhar Number'),
			'contactnum':('Contact Number'),
        }
