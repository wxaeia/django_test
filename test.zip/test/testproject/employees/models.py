from django.db import models

# Create your models here.

class Employee(models.Model):
    name = models.CharField(max_length=100,blank=True,null=True)
    # lastname = models.CharField(max_length=100,blank=True,null=True)
    # dateofBirth = models.DateField(auto_now=False, auto_now_add=False)
    aadharNumber = models.CharField(max_length=100,blank=True,null=True)
    gender = models.CharField(max_length=100,blank=True,null=True)
    contactnum = models.CharField(max_length=100,blank=True,null=True)
    salary = models.CharField(max_length=100,blank=True,null=True)
    # alternatenum = models.CharField(max_length=50,blank=True,null=True)
    address = models.CharField(max_length=100,blank=True,null=True)
    # joiningdate = models.DateField(auto_now=False, auto_now_add=False)
    # Martialstatus = models.BooleanField(blank=True,null=True)

