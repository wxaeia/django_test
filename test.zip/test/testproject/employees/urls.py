from django.urls import path,include
from employees import views
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)


urlpatterns = [
    path('login/',views.user_login,name='login'),
    path('signup/',views.user_signup,name='signup'),
    path('profile/',views.user_profile,name='profile'),
    path('logout/',views.user_logout,name='logout'),
    path('saveemployees/',views.saveemployees,name='saveemployees'),
    path('deleteemployees/',views.deleteemployees,name='deleteemployees'),
    path('editemployees/',views.editemployees,name='editemployees'),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]