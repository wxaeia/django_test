from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse
from django.contrib.auth import authenticate,login,logout,update_session_auth_hash
from django.contrib import messages
from datetime import datetime , timedelta
from employees.forms import AuthForm,NewSignUpForm
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth.decorators import login_required
from employees.models import Employee
from rest_framework import viewsets
from employees.serializers import EmployeeSerializer
from employees.forms import EmployeeForm
from django.views.decorators.csrf import csrf_exempt
import json


# Create your views here.

def user_signup(request):
	if request.method=='POST':
		fm = NewSignUpForm(request.POST)
		if fm.is_valid():
			fm.save()
			# messages.success(request,'Successfully user Added!!!')
			return HttpResponseRedirect('/login/')
	else:
		fm = NewSignUpForm()
	return render(request,'employees/signup.html',{'form':fm})


def user_login(request):
	if not request.user.is_authenticated:
		if request.method=='POST':
			fm = AuthForm(request=request,data=request.POST)
			if fm.is_valid():
				uname = fm.cleaned_data['username']
				password = fm.cleaned_data['password']
				user = authenticate(username=uname,password=password)
				if user is not None:
					login(request,user)
					obj = get_token_user(user)
					access = str(obj["access"])
					refresh = str(obj["refresh"])
					# return JsonResponse({"access":access,"refresh":refresh})
					return HttpResponseRedirect('/profile/')
				else:
					return HttpResponseRedirect('/login/')
		else:
			fm = AuthForm()
		return render(request,'employees/login3.html',{'form':fm})
	else:
		return HttpResponseRedirect('/profile/')

@login_required
def user_profile(request):
	if request.user.is_authenticated:
		fm = EmployeeForm()
		employeedata = Employee.objects.all()
		# serializer = EmployeeSerializer(employeedata, many=True)
		return render(request,'employees/profile.html',{'form':fm,'data':employeedata})
	else:
		return HttpResponseRedirect('/login/')

def user_logout(request):
	logout(request)
	return HttpResponseRedirect('/login/')

def get_token_user(user):
	tokens=[]
	refresh = RefreshToken.for_user(user)
	access = str(refresh.access_token)
	refresh = str(refresh)
	obj = {"access":access,"refresh":refresh}
	tokens.append(obj)
	return obj

class EmployeeViewSet(viewsets.ModelViewSet):
	queryset = Employee.objects.all()
	serializer_class = EmployeeSerializer
	# permission_classes = [IsAccountAdminOrReadOnly]
# @csrf_exempt
def saveemployees(request):
	if request.method == 'POST':
		form = EmployeeForm(request.POST)
		if form.is_valid():
			sid = request.POST['stuid']
			nm = request.POST['name']
			sal = request.POST['sal']
			aadh = request.POST['aadh']
			add = request.POST['add']
			num = request.POST['num']
			gen = request.POST['gen']

			print("id=================="+sid)
			if(sid == ""):
				emp = Employee(name=nm,aadharNumber=aadh,gender=gen,contactnum=num,salary=sal,address=add)
			else:
				emp = Employee(id=sid,name=nm,aadharNumber=aadh,gender=gen,contactnum=num,salary=sal,address=add)
			emp.save()
			empl = Employee.objects.values()
			empld = list(empl)
			print(empld)
			return JsonResponse({"status":"Success","empl_data":empld})
		else:
			return JsonResponse({"status":"Fail"})

@csrf_exempt
def deleteemployees(request):
	if request.method=="POST":
		id = request.POST.get("sid")
		emp = Employee.objects.get(pk=id)
		emp.delete()
		return JsonResponse({"status":"Success"})
	else:
		return JsonResponse({"status":"Fail"})


@csrf_exempt
def editemployees(request):
	if request.method=="POST":
		id = request.POST.get("sid")
		emp = Employee.objects.get(pk=id)
		empdata = {"id":emp.id,"name":emp.name,"aadharNumber":emp.aadharNumber,"gender":emp.gender,"contactnum":emp.contactnum,"salary":emp.salary,"address":emp.address}
		return JsonResponse(empdata)



